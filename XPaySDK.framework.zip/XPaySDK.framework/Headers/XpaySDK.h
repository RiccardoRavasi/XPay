//
//  XpaySDK.h
//  XpaySDK
//
//  Created by Nexi Spa on 07/12/16.
//  Copyright © 2018 Nexi Spa. All rights reserved.
//

#import <UIKit/UIKit.h>


//! Project version number for XpaySDK.
FOUNDATION_EXPORT double XpaySDKVersionNumber;

//! Project version string for XpaySDK.
FOUNDATION_EXPORT const unsigned char XpaySDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <XpaySDK/PublicHeader.h>


